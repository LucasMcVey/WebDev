function init()
{
    console.log("Hello, Practical 2"); // You can delete this.
}

init();
