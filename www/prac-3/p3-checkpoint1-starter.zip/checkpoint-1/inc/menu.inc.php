<ul id="menu">
    <li><a href="index.php">Tasks</a></li>
    <li><a href="add.php">Add</a></li>
    <li><a href="history.php">History</a></li>
</ul>
