<!DOCTYPE html>
<html lang="en">
<head>
    <title>Practical 3: Current tasks</title>
    <meta charset="UTF-8" />
    <meta name="author" content="<replace with your name>" />
    <!-- <script src="scripts/script.js" defer></script> -->
</head>
<body>
    <!-- <?php require_once "inc/menu.inc.php"; ?> -->
    <h1>Current</h1>
    <?php
    require_once "inc/dbconn.inc.php";

    // Add your code here

    ?>
</body>
</html>
